Terrain Expansion 2.0 ini
For Terrain Expansion 2.0
Courtesy of the Terrain Expansion site
This is provided as a courtesy for thaws that only want to edit maps and have installed the Terrain Expansion 2.0. This will not work with out the Terrain Expansion 2.0 installed and may cause the game to act in a undesirable manner or crash. 
Author DJBREIT

1. Install Information
2. Uninstall Information
3. Requirements
4. Disclaimer
5. Legal


===1 To install===
Must have Terrain Expansion 2.0 installed
Extract to RA2 dir

desertmd.ini
lunarmd.ini
snowmd.ini
temperatmd.ini
urbanmd.ini
urbannmd.ini

===2 To Uninstall===
remove or follow the Terrain Expansion 2.0 instructions.
desertmd.ini
lunarmd.ini
snowmd.ini
temperatmd.ini
urbanmd.ini
urbannmd.ini

===3 Requirements===
You will need RA2 and RA2/YR disk and the latest patch (v1.001 at the time of writing) also will require the Terrain Expansion 2.0 to be installed. This was tested with legally copies of RA2 and RA2 /YR If you have an illegally copy and have a problem then you are "SHIT OUT OF LUCK" since we don't support hacks.
This was also tested with FA2/YR 1.2 the unofficial map editor with some problems. See Terrain Expansion 2.0 instructions for know bug.

===4 Disclaimer===
The author does not make any warranties regarding the files in this archive. 
Users assume responsibility for the results achieved for computer program use and should verify applicability and accuracy.

===5 Legal===
The Yuri's Revenge Terrain Expansion 2.0 is � 2003 by Blade

You MAY NOT include the Yuri's Revenge Terrain Expansion or any of its components as part of any sort of commercial or promotional product without permission of Blade. blade@mysanctuary.demon.co.uk

You MAY NOT distribute the Yuri's Revenge Terrain Expansion or any of its components through any other means, except as part of a map or modification, and only when absolutely necessary to support mod-specific features which are not supported by the unaltered Yuri's Revenge Terrain Expansion. This .txt file (unaltered) must be included with any such map or mod, which requires bundling a modified version of the Yuri's Revenge Terrain Expansion. Please do use the Yuri's Revenge Terrain Expansion as a base for other mods or maps. If an alteration is needed for a map or mod, the files should be shipped with the map or mod as stated above.

If you make a tile set that you think can be added to the Terrain Expansion please post them at http://www.cannis.net/forum and will see if we can add them to the next version. We would like to maintain one Terrain Expansion so players, mappers and modders will have a minimum of compatibility problems and maximum technical support from the development team wherever possible. 
