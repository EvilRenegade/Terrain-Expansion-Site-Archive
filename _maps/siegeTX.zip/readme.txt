Author: Concolor1
Editor: FinalAlert2
Created:14th JAN, 2005

Name: Siege
Size: 90x98
Players: 1
Theatre: NewUrbanTX

To play this mission:The TX Terrain Expansion Pack is required!
The Yuris Revenge mission disc is also required. 
Extract the contents of the winzip file into your Red Alert2 Directory or desktop.
The mission will then be contained within the XCC Mod Launcher.
Launch the game,and the selected files will be placed temporaily in your RA2 Folder.
Select new campaign for the Allies.
The game will then launch.

                     "Siege---Written for the TX Expansion Pack"
                     -------------------------------------------
Intro:Due to poor command and communication in the field a situation has arose that only a Commander of the highest calibre will be able to salvage.
It seems the Soviets and her allies have been engaged in erratic and covert operations, which has caused the unique situation of one of our outposts being annexed without our foreseeing it.
The Soviets have surrounded this facility and laid siege, cutting-off all land routes and surrounding the zone with a heavy air defence!
The information gathered by this outpost is of "key", interest to the Allied high command and it has therefore fallen to you commander to hold the command centre in this base.
Having already shipped out and air-dropped into the battlezone you must waste no time in organising your defences before the Soviet bombardments and following attacks ensue.
Commander defending this vitally important outpost will by no means be an easy task. Should the base remain standing and all traces of the Soviet blight in the zone are eradicated,
your promotion in the ranks will be guaranteed!


To Activate the help text for this mission play "Easy" mode and destroy the flag next to the Allied Barracks.
 


Ok so there u have it,


NEW UNITS
---------

Robotic Demolition Drone
------------------------
Recent Advances in Allied technology has resulted in the highly regarded Robotic Demolition Drone. We have replaced the standard gun in favour of a mini nuclear generator. This ensures the unit continues to function
if the Robot Command Centre gets damaged. However these units are one shot wonders, Once directed to their objective they will detonate if they come against any opposition, making large swarms of them extremely effective!
Take care in constructing these units, too many within the base could result in disaster, as the fallout will damage our own structures and units! --- Construction Special --- 

Vengeance Tank
-------------
The Allies in a past campaign against the tyrant Yuri salvaged several of his Gattling tanks. After some careful reverse engineering we have created an allied version of this tank. Supremely accurate and fast, these tanks have
a far reaching range and become deadly in numbers. Ideal for both attack and defence.

Delta Force
-----------
Special operations infantry units. Fast, self healing, equipped with state of the art laser targeting weapons, explosives, a couple of these units can quickly overrun and destroy any number of targets. --- Construction Special --- 

Landing Pad
-----------
The Allies realised that building airforce command centres which simply controlled four air units was a wasted resource. They have now refined this technology, and eliminated the need for more than one air command centre.
In it's place they have constructed a simple landing pad that will take a further four aircraft. 

Flamer Tank
----------
The Soviets call this tank "The Blaze of Glory",
Lethal and highly feared by the infantry. These units can decimate large numbers of enemy troops before they succumb. Ideal for your bridgehead invasions. Equipped with a twin flamer capable of incinerating the most hardy of targets.

Mauler Tank
-----------
Another Soviet propaganda weapon.
More feared than any other unit in the field is the Mauler tank. Subterranean in nature this unit can appear just about anywhere in the battlezone. Although somewhat encumbered by its short range weapon, this unit relies on suprise. Appearing
where defences are weak and completely chewing-up any light opposition. Ideal for covert operations this unit can destroy all manner of targets! --- Construction Special --- 

Hammer & Sickle Tank
-------------------- 
This is the Soviet ultimate answer to crushing all opposition!
Highly prized and most lethal is the Soviet Hammer and Sickle Seismic tank. As the name suggests this vehicle can bring bases to their knees. From a long range this unit can pound the very earth creating devastating quakes. One unit alone is enough
to end the most determined of sieges. Together a few positioned carefully can end a war!
Their advantage however comes at a high price. Although unapproachable on land once activated these units have no defence from Ariel attacks!

YAK-24
------
Realising their disadvantage in air transport the Soviets designed and created the Yak-24 transport helicopter. Capable of transporting and landing conscripts right into the heart of the battle. This particular unit sacrifices armaments for payload, and although 
weak its manoeuvrability sometimes confuses the allied defences. Ideal for landing small infantry taskforces into enemy territory!

Tesla Commando
--------------
Equipped with a far more powerful tesla charge, this Soviet infantry unit can do some serious damage to the enemy!




All the files with the exception of the TX expansion pack have been supplied in this Mod.
These are as follows all01umd.map
                     ra2.md.csf
                     art.md
                     rules.md
                     yakicon.shp
                     yak.vxl
                     yak.hva
                     ftnk.vxl
                     ftnk.hva
                     ggapadmk.shp
                     ggapadbb.shp
                     ggapad_d.shp
                     ggapad_b.shp
                     ggapad.shp
                     gaapadbb.shp
                     gaapadmk.shp
                     gaapad_b.shp
                     gaapad.shp
                     apadicon.shp
                     deltauico.shp
                     deltaicon.shp
                     delta.shp
                     sftnk.vxl
                     sftnk.hva
                     dig.shp
                     shkcomuico.shp
                     shkcom.shp
                     shkcomicon.shp
                     pulseball2.shp
                     ftnkicon.shp
                     ftnkuicon.shp
                     maukicon.shp
                     maukuicon.shp
                     MRB.shp
                     RoboDemo.vxl
                     RoboDemo.hva
                     RoboDemotur.vxl
                     RoboDemotur.hva
                     RoboDemoicon.shp
                     Vengeance.vxl
                     Vengeance.hva
                     Vengeancetur.vxl
                     Vengeancetur.hva
                     Vengicon.shp
                     Venguicon.shp
                     Seis.hva
                     Seis.vxl
                     Seistur.hva
                     Seistur.vxl
                     Seistur1.hva
                     Seistur1.vxl
                     Seistur2.hva
                     Seistur2.vxl
                     Seistur3.hva
                     Seistur3.vxl
                     Seistur4.hva
                     Seistur4.vxl
                     Seistur5.hva
                     Seistur5.vxl
                     Seisicon.shp
                     Is800a01.shp
                     Is800a01.pal
                     banner.jpeg
                     
expandmd98.mix,ecachemd98.mix, and ra2md.csf, are written by the launcher ito your RA2 directory when the Mod is launched.

Various slight moddifications have been added, all to keep in with this missions theme. The moddifications will not alter your 
original RA2 game.

For some time I was taken with the idea of adding new units and structures to Red Alert2, whilst still retaining the games unique style. So with the release of the TX and with the help of an extremely
dedicated community, I am honoured to be able to produce my MOD mission. Introducing new units, produced by the top class in the community Mauler tanks, Flamer Tanks, Robotic Demoition Drones, Seismic tanks,
and the Vengeance Tank all appear in this mission along with Delta force and Giant Beetles for those lucky enough to find them!
---------------------------------------THANKYOU TO EVERYONE---------------------------------------------------------------------

This is a "BIG", community effort, and its very nice for me to get everyone involved in some way shape or form. The community is full of highly dedicated and knowledgable people, without which
the Red Alert game popularity would of ground to a halt. This mission involves some of the best of the best, and it's always nice to get everyone together, even if I have to be a little diplomatic about it.
So at the end of this long and sometimes testing mission I just want to say a very big thankyou to the community -- you guys are great!
Major_Gilbear actually took alot of time to produce some exciting new voxels for this mission. The Robotic Demo Drone is awsome!
spider-man_2099 especially went to great trouble to supply me with a unique subterranian unit just for this mission, the outstanding Mauler Tank!
Both of the above units being my favorites!

Finally a big thankyou to the following people who have given so much
help in this field with their ideas and solutions......the TX missions are a product of the RA2 Community and no one person.


First and Foremost none of this would of been possible without the TX (Terrain Expansion). This is something that many of us in the
community truely appreciate and for me its a godsend. Now with the addition of tunnels and extra terrian, waterfall animations ect,
the game is so much more than it was.
So my personal thanks to Blade for this(and the loadscreen he made), MooMan and D.J.BREIT both for their tireless work in getting this project out to us in the community.
MooMan's pallet conversions for the New Urban and Lunar Theatre's being an inigral part of the TX.
D.J.BREIT's contributions to the tunnels and terrain set are outstanding and highly appreciated.
Second up, always there to help is Cannis. If it were not for his help and paitience in explaining practically everything, none of the missions
Ive made would have been possible, for my part I do my best to pass what Ive learn't on. Also for the crafty spy-sat trick solving the reshroud bug for me.
Major_Gilbear - created the artwork for both Vengence Tank and the allied RoboDemo Drone. Slaving away at something which he had a long wait to see in action. Hope Ive done
your work justice in this mission thankyou again for all your hard work!
Cannis always a help and inspiration in this instance provided the "true random", effects which bring on reinforcements.
He also found the time at the very end to grace this MOD with a launcher, this is the reason the mission is now ready for you all! Everybody say Thankyou!
spider-man_2099 & Major_Gilbear both designed and supplied the maulertank this was started by spidey and completed by Major, to whom I am very greatful for the voxel.
spider-man_2099 also let me use his flametank and Yak-24 Voxels Cannis had a hand in the Yak too.
Spidey very kindly supplied the Cameo for the new tanks, which has vastly speeded up the release of this project. mrruben5 finished this off for me, so now we have a truely awsome Cameo which looks great. Thanks for that guys.
Cannis and Sypher again for the use of their allied launchpad and rules which are added to the rulesmd.file.
Viscera for the use of his Mutant Rhino Beetle, which come something close to the Ants from the original Red Alert Game.
This Mod Mission also features the "Hammer and Sickle", unit from the very popular Deezire Mod, coded by Deezire. Permission was sought for the use of this unit. Blade who I understand had a hand in this units development confimed that
so long as it was properly credited things would be cool if I wanted to feature this unit.
MooMan65 simply for the support and past advice and being part of the core community.
Blade also supplied me with rules and avice regarding Flame units, as did Seaman--without that help this mission would never of been.
Medalmonkey for using his Delta force unit and modified rules.
Deezire.net for futher refinement and guidence relating to units and rules.
ArgCmdr for his help with converting the subflammer cameos made by spider-man_2099, and for suppliying me with the information on subterraenean units. He also went to alot of trouble recolouring animations,cameos and giving advice.
This ment alot of late nights offering suggestions sending me files and recolouring animations ect. It's very much appreciated Thanks again ArgCmdr.
Dark_Elf_2001 for his excellent Telsa Commando. I renamed Psycho's icon for the Tesla Vanguard for this unit.
FlyingZ for explaining why the bugs were not attacking infantry.
DCoder, Clazzy and Major Gilbear and Carnotaurus for suggestions and expertise in the field of weapons design and why they weren't working in certain situations.
Sypher, for all his help, suggestions and explanations with the TX, he's a busy guy!
RVMech, for the script actions used in the mapfile for copywrite and authorship purposes.
Olaf Van der Spek for the XCC utilities and the MOD launcher with which this mission is to be launched.
Finally thanks to Matze,for the FA2 utility,and the RA2 CSF Editor, without such tools none of this would of been possible.
(I really do hope that I haven't missed anyone, as this mission is such an important realease for me being my first MOD mission).
  

XCC utilities http://xccu.sourceforge.net/.

                           

Other missions available.....1> Signed & Sealed.
                             2> Temporal Exposure.
                             3> Soviet Stranglehold.
                             4> Prisoner of Conscience.
                             5> The Wolves of Winter.
                             6> Fierce Intent.
                             7> Shock Tactics.
                             8> Dominance in Mind.
                             9> Weathering the Storm.
                            10> In Cold Storage.
                            11> Identity Crisis.
                            12> Terminal Lunacy.
                            13> Under Pressure.
                            14> Robot Revolution.
                            15> Nuclear Winter.(Exclusive to http://www.cannis.net/concolor1/)
                            16> Day of the Desolators
                            17> Last Post.(Exclusive to http://www.cncgames.com/maps_ra2missions.shtml)
                            18> Engineered to Kill.
                            19> Jungle Fortress.
                            20> Company of Wolves.
                            21> End of an Era.
                            22> Moon-Madness. (requires the TX to run).
                            23> Siege (requires the TX to run).

Concolor1------puma129@hotmail.com

Downloads available at www.cncgames.com/
                       http://www.cannis.net/concolor1/ 
                       
Links
------
http://mooman.cannis.net/
http://project.cannis.net/
http://www.cannis.net/cannisrules/
http://pixelops.cannis.net/
http://yrarg.cncguild.net/
www.cncgames.com/
                       
                      
                       
                      


                      ======================
                      ======================

 All units featured in this mission are copywrite to the authors, and any person wishing to make use of these must seek out permission from their creators.
*Included files:
[Seige all01umd.map] (the map)
[Seige].[.gif] (preview image)
[Readme file].txt (this file)
[md.csf],(text game file)
[yak.vxl](copywrite spider-man_2099 & Cannis(Enhanced Normals by Me2))
[yak.hva](copywrite spider-man_2099 & Cannis(Enhanced Normals by Me2)) 
[yakicon.shp](original artwork copywrite spider-man_2099)
[ftnk.vxl] (copywrite spider-man_2099)
[ftnk.vxl] (copywrite spider-man_2099)
[rules.md](rules file)
[art.md](artwork file)
Is800a01.shp(loadscreen by Blade)
Is800a01.pal(loadscreen by Blade)
banner.jpeg(by Cannis)
[ggapadmk.shp] (copywrite Sypher_5 & Cannis)
[ggapadbb.shp] (copywrite Sypher_5 & Cannis)
[ggapad_d.shp] (copywrite Sypher_5 & Cannis)
[ggapad_b.shp] (copywrite Sypher_5 & Cannis)
[ggapad.shp]   (copywrite Sypher_5 & Cannis)
[gaapadbb.shp] (copywrite Sypher_5 & Cannis)
[gaapadmk.shp] (copywrite Sypher_5 & Cannis)
[gaapad_b.shp] (copywrite Sypher_5 & Cannis)
[gaapad.shp]   (copywrite Sypher_5 & Cannis)
[apadicon.shp] (copywrite Sypher_5 & Cannis)
[deltauico.shp] (copywrite Medalmonkey)
[deltaicon.shp] (copywrite Medalmonkey)
[delta.shp]     (copywrite Medaymonkey)
[sftnk.vxl]    (copywrite Major_Gilbear & spider-man_2099)
[sttnk.hva]    (copywrite Major_Gilbear & spider-man_2099)
[ftnkicon.shp] (artwork copywrite spider-man_2099)
[ftnkuicon.shp](artwork copywrite spider-man_2099)
[maukicon.shp] (artwork copywrite spider-man_2099)
[maukuicon.shp](artwork copywrite spider-man_2099)
[dig.shp]      (supplied by ArgCmdr)
[pulseball2]   (supplied by ArgCmdr)
[MRB.shp]      (copywrite Viscera)
[RoboDemo.shp] (copywrite Major_Gilbear)
[RoboDemo.hva] (copywrite Major_Gilbear) 
[RoboDemotur.shp] (copywrite Major_Gilbear)
[RoboDemotur.hva] (copywrite Major_Gilbear)
[RoboDemoicon.shp] (copywrite Concolor1)
[Vengeance.shp] (copywrite Major_Gilbear)
[Vengeance.hva] (copywrite Major_Gilbear)
[Vengeancetur.shp](copywrite Major_Gilbear)
[Vengeancetur.hva](copywrite Major_Gilbear)
[New Turrets for IFVs](copywrite Cannis & Syper_5)
[Seis.hva] (copywrite original design by IIRC viceroidgod, Deezire & Blade)
[Seis.vxl] (copywrite original design by IIRC viceroidgod, Deezire & Blade)
[Seistur.hva](copywrite original design by IIRC viceroidgod, Deezire & Blade)
[Seistur.vxl](copywrite original design by IIRC viceroidgod, Deezire & Blade)
----------Turret Animations by Blade.---------
[Seistur1.hva](copywrite Deezire & Blade)
[Seistur1.vxl](copywrite Deezire & Blade)
[Seistur2.hva](copywrite Deezire & Blade)
[Seistur2.vxl](copywrite Deezire & Blade)
[Seistur3.hva](copywrite Deezire & Blade)
[Seistur3.vxl](copywrite Deezire & Blade)
[Seistur4.hva](copywrite Deezire & Blade)
[Seistur4.vxl](copywrite Deezire & Blade)
[Seistur5.hva](copywrite Deezire & Blade)
[Seistur5.vxl(copywrite Deezire & Blade)
[Seisicon.shp](copywrite Deezire,Mooman & Blade)
[Shkcom.shp] (copywrite Dark_Elf_2001]
[Shkcomicon.shp] (copywrite Psycho]
[Shkcomuicon.shp](copywrite Psycho]
[Vengicon.shp] (copywrite Concolor1]
[Venguicon.shp](Copywrite Concolor1]



                          ===Legal===
This Red Alert 2 mission '[Siege]' is � 2004 by [Concolor1].
You MAY NOT include this map as part of any sort of commercial or promotional product without my permission.
You MAY Not distribute this map on websites or in mappacks without my permission.
If offered from a WWW or FTP site or similar, this .txt file (unaltered) must be included.
Please do not use this map as a base for other maps.
Please seek permission before uploading onto a site.
                      =====================
                      =====================
                        copyright � 2004



