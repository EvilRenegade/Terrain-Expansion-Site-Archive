-author: Truefeel
-requirements: red alert 2: yuri's revenge (patched up to 1.001) and Terrain Expansion.
-map info:
name: rocket red glare 2
map size: 100x100
theatre: snow

-instructions:
this a complete rebuild of the map rockets red glare in snow theatre. after the the war raged over the city,
the city was lie�ng in ruins; home destroyed, civilians murdered,... . thought the city managed to hold out.
now, the war is going back to the city with a third side: yuri. will the city hold out war or will it burn completely down ??
that's up for you to decide !! the army is protecting the city, so watch out, they patrol in the city. if you harm the civilians, the army is going to pay
you a little visit. if ALL civilians and the army units are destroyed, the army drops a nuke bomb on each player location. you will be warned about that thought.
also, the civilians are angry on the players, the will try to bomb you with trucks filled with explosives!! to stop that, you need to destroy the facility where they are been
created. garrisoning buildings is difficult cause they are heavily damaged.
you start out in the darkness, there's a slow moving day/night loop.

ok, enjoy this great detailed map!!

Truefeel

-credits to:

betatesters:
yuriruler90
zero2
stordoff
flak

thanks, guys !!

day/night loop:
RVMECH: thanks, man, you're loop is really good.