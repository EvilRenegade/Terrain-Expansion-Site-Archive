**Turtle Town (TX)**
A multiplayer map for Yuri's Revenge

Map Info...
=========

Author: seniorwhoppy
Map Name: Turtle Town (TX)
Game(s) Supported: Yuri's Revenge
Players: 2-4
Size: 90x94
Theater: New Urban
Resources: Heavy
Format: .YRM
File Size: 115kb Zipped with readme & jpg, Map 184kb
Editors Used: FA2YR, Wordpad
Map Release Date: 09/06/05



Map Description...
==============
A map that has been designed to allow for secure bases. However, if you want to have a fighting chance you can't cut yourself off completely.


Tips:
Don't cut yourself off from the middle of the map otherwise you will run into trouble very quickly.
The oil derricks produce more cash but they are very vulnerable use them wisely.

Requirements...
============

You need to have Red Alert 2, Yuri's Revenge Expansion and the Terrain Expansion V2.02 or Later installed to play this map.


Install & Run...
============

Attached Files:
(TX) Turtle Town (2-4).yrm } (The YR map)
(TX) Turtle Town (2-4).jpg (Preview image)
(TX) Turtle Town (2-4) Readme.txt (This file)

Place Turtle Town (TX).yrm in your \RA2\ Directory. Start Yuri's Revenge and the map should appear on the map list.

Battle/FFA, Meatgrinder, Navalwar, and TeamAlliance game modes are supported.


Modifications...
===========

Mirage tanks will mimic any of the trees that appear on this map
All the Oil Derricks on this map now produce 75% of the original total 'load' but give more cash when captured.
The ore mines in the center of the map are 5x more productive than before.
Bridges are indestructible.


Known Bugs...
===========




Credits...
========

Thanks to Westwood for a 'great' game
Matze for the map editor FA2YR101
Thanks to Dark Scorpion for introducing me to YR, and the Joys of Map Making
Thank you to people who tested and commented on the map, you were a great help.


Disclaimer...
==========
The creator does not make any warranties regarding the files in this archive. Users assume responsibility for the results achieved for computer program use and should verify applicability and accuracy.


Legal...
=======

The Red Alert 2 / Yuri's Revenge map 'Turtle Town (TX)' is a 16/05/05 production by seniorwhoppy
If you want to upload it somewhere else make sure you ask me first etc etc......

Enjoy, and comments are always welcome!!
- seniorwhoppy (agardner14@excite.com)