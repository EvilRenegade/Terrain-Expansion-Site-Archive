Author: Concolor1
Editor: FinalAlert2
Created:11th August, 2003

Name: Moon-Madness
Size: 90x90
Players: 1
Theatre: LunarTX

To play this mission:The TX Terrain Expansion Pack is required!
The Yuris Revenge mission disc is also required. 
Extract the contents of the winzip file into your Red Alert2 Directory or desktop.
The mission will then be contained within the XCC Mod Launcher.
Launch the game,and the selected files will be placed temporaily in your RA2 Folder.
Select new campaign for the Allies.
The game will then launch.

                     "Moon-Madness---Written for the TX Expansion Pack"
                     --------------------------------------------------

Info: The Soviets have built and designed their very own Robot controlled tanks. These are Ideally suited to all types of environments, better equipped and better armed than the Allied counterparts. A production facility has been constructed on the moon.
This Moonbase appears to be one of the key elements in the funding behind the Soviet war efforts, and tapping into the moons hidden resources is what the Soviets have set about doing.
A small Allied base has been established in a hidden crevas close to the Soviet operations. Use the limited units available and destroy the Soviet Robot Command Center,  once offline the Russian facilitiy will be relatively undefended and ours for the taking.

 Objective 1: Destroy the Soviet Robot Command Center.
 


Ok so there u have it,
All the files with the exception of the TX expansion pack have been supplied in this Mod.
These are as follows all01umd.map
                     ra2.md.csf
                     art.md
                     rules.md
                     sovdrone.vxl
                     sovdronetur.vxl
                     sovdrone.hva
                     sovdronetur.hva
                     srobouico.shp
                     sroboicon.shp
                     chaos.vxl
                     chaostur.vxl
                     chaos.hva
                     chaostur.hva
                     dfnduico.shp
                     Is800a01.shp
                     Is800a01.pal
                     banner.jpeg
                     
expandmd98.mix,ecachemd98.mix, and ra2md.csf, are written by the launcher ito your RA2 directory when the Mod is launched.

Various slight moddifications have been added, all to keep in with this missions theme. The moddifications will not alter your 
original RA2 game.



Finally a big thankyou to the following people who have given so much
help in this field with their ideas and solutions......

Ok new list not a copy and paste job this time..lol
First and Foremost none of this would of been possible without the TX (Terrain Expansion). This is something that many of us in the
community truely appreciate and for me its a godsend. Now with the addition of tunnels and extra terrian, waterfall animations ect,
the game is so much more than it was.
So my personal thanks to Blade for this(and the loadscreen he made), MooMan and D.J.BREIT both for their tireless work in getting this project out to us in the community.
MooMan's pallet conversions for the New Urban and Lunar Theatre's being an inigral part of the TX.
D.J.BREIT's contributions to the tunnels and terrain set are outstanding and highly appreciated.
Second up, always there to help is Cannis. If it were not for his help and paitience in explaining practically everything, none of the missions
Ive made would have been possible, for my part I do my best to pass what Ive learn't on. Also for the crafty spy-sat trick solving the reshroud bug for me.
Cannis in this instance provided the "true random", effects which bring on reinforcements and create the storms. He also very kindly completed 
the Cameo for the Soviet tank, that those lucky enough to capture will appreciate.
spider-man_2099 for the terrific Soviet Robot tank Voxel, I really wanted to use this for the mission, and appreciate his genorosity in granting
me that privalliage, (hope the rules for this tank please you). He also very kindly supplied the Cameo for the Robot Tank, which has vastly speeded
up the release of this project. Cannis finished this off for me, so now we have a truely awsome Cameo which looks great. Thanks for that guys.
This Mod Mission also features the unique "Defender", unit from the very popular EagleRed Mod, one of my favorites and its highly recommended.
Eagle very generously consented to let me use this unit, which I felt was paramount to the defence of the Soviet moonbase.
Sypher, for all his help, suggestions and explanations with the TX,and for making me the banner jpeg which graces the launcher screen.
RVMech, for the script actions used in the mapfile for copywrite and authorship purposes.
Olaf Van der Spek for the XCC utilities and the MOD launcher with which this mission is to be launched.
Finally thanks to Matze,for the FA2 utility,and the RA2 CSF Editor, without such tools none of this would of been possible.
(I really do hope that I haven't missed anyone, as this mission is such an important realease for me being my first MOD mission).
  

XCC utilities http://xccu.sourceforge.net/.

                           

Other missions available.....1> Signed & Sealed.
                             2> Temporal Exposure.
                             3> Soviet Stranglehold.
                             4> Prisoner of Conscience.
                             5> The Wolves of Winter.
                             6> Fierce Intent.
                             7> Shock Tactics.
                             8> Dominance in Mind.
                             9> Weathering the Storm.
                            10> In Cold Storage.
                            11> Identity Crisis.
                            12> Terminal Lunacy.
                            13> Under Pressure.
                            14> Robot Revolution.
                            15> Nuclear Winter.(Exclusive to http://www.cannis.net/concolor1/)
                            16> Day of the Desolators
                            17> Last Post.(Exclusive to http://www.cncgames.com/maps_ra2missions.shtml)
                            18> Engineered to Kill.
                            19> Jungle Fortress.
                            20> Company of Wolves.
                            21> End of an Era.(to be released)
                            22> Moon-Madness. (requires the TX to run)


Concolor1------puma129@hotmail.com

Downloads available at www.cncgames.com/
                       http://www.cannis.net/concolor1/ 
                       
                       
                      
                       
                      


                      ======================
                      ======================
*Included files:
[Moon-Madness all01umd.map] (the map)
[Moon-Madness].[.gif] (preview image)
[Readme file].txt (this file)
[md.csf],(text game file)
[sovdrone.vxl](copywrite spider-man_2099)
[sovdronetur.vxl](copywrite spider-man_2099)
[sovdrone.hva](copywrite spider-man_2099)
[sovdronetur.hva](copywrite spider-man_2099)
[srobouico.shp](original artwork copywrite spider-man_2099) 
[sroboicon.shp](original artwork copywrite spider-man_2099)
[chaos.vxl](original artwork copywrite Eagle (EagleRed))
[chaostur.vxl](original artwork copywrite Eagle (EagleRed))
[chaos.hva](original artwork copywrite Eagle (EagleRed))
[chaostur.hva](original artwork copywrite Eagle (EagleRed))
[dfnduico.shp](original artwork copywrite Eagle (EagleRed))
[rules.md](rules file)
[art.md](artwork file)
Is800a01.shp(loadscreen by Blade)
Is800a01.pal(loadscreen by Blade)
banner.jpeg(by Sypher_5)

                          ===Legal===
This Red Alert 2 mission '[Moon-Madness]' is � 2003 by [Concolor1].
You MAY NOT include this map as part of any sort of commercial or promotional product without my permission.
You MAY Not distribute this map on websites or in mappacks without my permission.
If offered from a WWW or FTP site or similar, this .txt file (unaltered) must be included.
Please do not use this map as a base for other maps.
Please seek permission before uploading onto a site.
                      =====================
                      =====================
                        copyright � 2003



